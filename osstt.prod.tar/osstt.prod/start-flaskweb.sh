#!/bin/bash

NAME="OSSTopTrending" # name of the application
FLASKDIR="/home/osstt_user/osstt.prod" # flask project directory
USER=osstt_user # the user to run as
NUM_WORKERS=6 # how many worker processes should Gunicorn spawn. default 3
FLASK_WSGI_MODULE=gitmostwanted # WSGI module name

echo "Starting $NAME as `whoami`"

# Activate the virtual environment
# Do not use virtualenvwrapper inside here. It will keep on looking for\
# the virtualenv folder at main root folder of linux and not inside /home.
source /home/osstt_user/.venvs/osstt/bin/activate

export PYTHONPATH=/home/osstt_user/osstt.prod
export GMW_APP_ENV=production
export GMW_APP_SETTINGS=/home/osstt_user/osstt.prod/instance.cfg

# Start the Green Unicorn
# Programs meant to be run under supervisor should not daemonize themselves (do not use --daemon)
cd $FLASKDIR

gunicorn gitmostwanted.web:app -b 0.0.0.0:5000 \
    --reload \
    --name $NAME \
    --workers $NUM_WORKERS \
    --log-level=debug \
    --log-file=-
