# pylint: disable=C1001
class Config:
    # Custom
    DEBUG_FILE = '/tmp/gmw.log'

    # Flask
    PERMANENT_SESSION_LIFETIME = 1209600  # 14 days
    SECRET_KEY = ''
    TESTING = False
    DEBUG = True

    # SQLAlchemy
    SQLALCHEMY_ECHO = False
    SQLALCHEMY_POOL_RECYCLE = 3600
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Celery
    CELERY_TIMEZONE = 'Asia/Seoul'
    CELERY_BROKER_URL = ''

    # Oauth
    GITHUB_AUTH = ('osstt', '89afc84ee0b5cbe40cdbb17d7c9158dbcd2b87b7')


class ConfigDevelopment(Config):
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    SQLALCHEMY_ECHO = True


class ConfigTesting(Config):
    SECRET_KEY = 'testing'  # noqa
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://osskr:hell0world@14.63.171.10:13306/testdb?charset=utf8'


class ConfigProduction(Config):
    DEBUG = False
