# -*- coding: utf-8 -*-
from flask import abort, Blueprint, g, request, render_template, make_response
from sqlalchemy import text
from gitmostwanted.models.repo import Repo, RepoMean
from gitmostwanted.models.user import UserAttitude
from gitmostwanted.models import report
from gitmostwanted.app import db
import numpy as np
import pandas as pd
import datetime

repo_trending = Blueprint('repo_trending', __name__)

_4_DAYS = 4
_7_SETS = 7
_28_DAYS = _4_DAYS * _7_SETS


# @repo_trending.route('/', defaults={'rng': 'day'})
@repo_trending.route('/', defaults={'rng': 'week'})
@repo_trending.route('/trending/<rng>/')
def list_by_range(rng):
    # map_list = {'day': 'ReportAllDaily', 'week': 'ReportAllWeekly', 'month': 'ReportAllMonthly'}
    map_list = {'week': 'ReportAllWeekly', 'month': 'ReportAllMonthly'}
    model = getattr(report, map_list.get(rng, map_list.get('week')))

    query = Repo.filter_by_args(model.query, request.args)\
        .join(Repo)\
        .order_by(model.cnt_watch.desc())

    if not g.user:
        query = query.add_columns(db.null())
    else:
        query = UserAttitude.join_by_user_and_repo(query, g.user.id, Repo.id)\
            .add_columns(UserAttitude.attitude)

    return render_template('index.html', entries=query, languages=Repo.language_distinct())


@repo_trending.route('/trending/details/<int:repo_id>')
def details(repo_id):
    repo = Repo.query.get(repo_id)
    if not repo:
        return abort(404)

    means = RepoMean.query.filter(RepoMean.repo_id == repo_id)

    return render_template('repository/details.html', entry=repo, means=means)


@repo_trending.route('/trending/download/<string:year>', methods=('get',))
def download(year):
    stmt = text("""
        SELECT
            A.id
            , A.html_url
            , A.name
            , B.doy
            , B.cnt_sum AS SUM
            , B.cnt_watch AS STARS
            , B.cnt_fork AS FORKS
            , B.cnt_commit AS COMMITS
            , B.cnt_pullrequest AS PULLREQUESTS
            , B.cnt_issue AS ISSUES
        FROM repos A, repos_stars_record B
        WHERE A.id = B.repo_id
            AND B.year = %s
        ORDER BY B.doy, A.id
        """ % year)

    try:
        conn = db.session.connection()
        df = pd.read_sql(stmt, conn)
    except:
        return abort(500)
    finally:
        conn.close()

    table = pd.pivot_table(df, index=["id", "html_url", "name"], columns="doy",
        values=["SUM", "STARS", "FORKS", "COMMITS", "PULLREQUESTS", "ISSUES"], aggfunc=np.sum, margins=True)

    stats = table.fillna(0).astype(int)
    stars_frame = stats["SUM"]
    frames_by_28days = get_frames_by_28days(stars_frame)

    _28day_averages_list = []
    for frame in frames_by_28days:

        _28day_averages = []
        for stars_by_repo in frame.values:

            _28day_averages.append(get_28day_avg(stars_by_repo))

        _28day_averages_list.append(_28day_averages)
        _28day_averages.append(sum(_28day_averages))

    stats = stats.swaplevel(0, 1, axis=1).sortlevel(0, axis=1)
    stats = stats.rename(columns={"All": "Tot"}, index={"All": "Tot"})

    for i in range(len(_28day_averages_list)):
        # location = (len(stats.columns.levels[1]) * _28_DAYS) * (i + 1) + i
        location = (6 * _28_DAYS) * (i + 1) + i
        stats.insert(location, '28day_avg_' + str(i), _28day_averages_list[i])

    filename = "osstt_%s.csv" % datetime.datetime.now().strftime("%Y%m%d%H%M%S")

    response = make_response(stats.to_csv())
    response.headers["Content-Disposition"] = "attachment;filename=" + filename
    response.headers["Content-Type"] = "text/csv"

    return response


def get_frames_by_28days(stars_frame):
    frames_by_28days = []
    num_of_frames = int((len(stars_frame.columns) - 1) / _28_DAYS)
    frames_by_28days = [stars_frame.ix[: - 1, i * _28_DAYS:(i + 1) * _28_DAYS] for i in range(num_of_frames)]

    return frames_by_28days


def get_28day_avg(stars_by_repo):
    _7_by_4_matrix = stars_by_repo.reshape(_7_SETS, _4_DAYS)
    _4day_avg_7sets = []

    for stars_for_4day in _7_by_4_matrix:
        variance = stars_for_4day.var()
        if variance < 1000:
            _4day_avg_7sets.append(stars_for_4day.mean())
        else:
            _4day_avg_7sets.append(1.0)

    _28_day_avg = np.asarray(_4day_avg_7sets).mean()

    return _28_day_avg

