from gitmostwanted.models.repo import Repo, RepoStars, RepoStarsRecord
from gitmostwanted.app import app, db, celery
from gitmostwanted.services import bigquery
from gitmostwanted.lib.bigquery.job import Job
from datetime import datetime, timedelta
from time import sleep


def results_of(j: Job):
    while not j.complete:
        app.logger.debug('The job is not complete, waiting...')
        sleep(10)
    return j.results


@celery.task()
def stars_mature(num_days):
    date_from = (datetime.now() + timedelta(days=num_days * -1)).strftime('%Y-%m-%d')
    service = bigquery.instance(app)
    query = """
        SELECT
            COUNT(1) AS stars, YEAR(created_at) AS y, DAYOFYEAR(created_at) AS doy, SUM(IF(type = 'WatchEvent', 1, 0)) as cnt_watch,  SUM(IF(type = 'ForkEvent', 1, 0)) as cnt_fork, SUM(IF(type='CommitCommentEvent', 1, 0)) as cnt_commit
        FROM
            TABLE_DATE_RANGE(
                [githubarchive:day.], TIMESTAMP('{date_from}'), CURRENT_TIMESTAMP()
            )
        WHERE repo.id = {id} AND type IN ('WatchEvent', 'ForkEvent', 'CommitCommentEvent')
        GROUP BY y, doy
    """
    jobs = []

    repos = Repo.query.filter(Repo.mature.is_(True)).filter(Repo.status == 'new').limit(1000)
    for repo in repos:
        job = Job(service, query.format(id=repo.id, date_from=date_from), batch=True)
        job.execute()
        jobs.append((job, repo))

    for job in jobs:
        for row in results_of(job[0]):
            db.session.add(RepoStars(repo_id=job[1].id, stars=row[0], year=row[1], day=row[2], cnt_watch=row[3], cnt_fork=row[4], cnt_commit=row[5]))

        job[1].status = 'unknown'

        db.session.commit()


@celery.task()
def stars_recording(num_days):
    service = bigquery.instance(app)
    RepoStarsRecord.query.delete()
    query = """
        SELECT
            YEAR(created_at) AS y, DAYOFYEAR(created_at) AS doy, COUNT(1) AS TOTAL,
            SUM(IF(type = 'WatchEvent', 1, 0)) as WATCH,  SUM(IF(type = 'ForkEvent', 1, 0)) as FORK,
            SUM(IF(type='CommitCommentEvent', 1, 0)) as COMMITS,
            SUM(IF(type='PullRequestEvent', 1, 0)) AS PULLREQUESTS,
            SUM(IF(type='IssuesEvent', 1, 0)) AS ISSUES
        FROM
            (
                TABLE_DATE_RANGE(
                    [githubarchive:day.], TIMESTAMP('2017-01-01'), CURRENT_TIMESTAMP()
                )
            )
        WHERE repo.id = {id} AND type IN ('WatchEvent', 'ForkEvent', 'CommitCommentEvent', 'PullRequestEvent', 'IssuesEvent')
        GROUP BY y, doy
        ORDER BY y, doy
    """

    jobs = []

    repos = Repo.query.filter(Repo.mature.is_(True)).order_by(Repo.stargazers_count.desc()).order_by(Repo.forks_count.desc()).limit(1000)

    for repo in repos:
        job = Job(service, query.format(id=repo.id), batch=True)
        job.execute()
        jobs.append((job, repo))

    for job in jobs:
        for row in results_of(job[0]):
            db.session.add(RepoStarsRecord(repo_id=job[1].id, year=row[0], doy=row[1], cnt_sum=row[2], cnt_watch=row[3], cnt_fork=row[4], cnt_commit=row[5], cnt_pullrequest=row[6], cnt_issue=row[7]))

        db.session.commit()

