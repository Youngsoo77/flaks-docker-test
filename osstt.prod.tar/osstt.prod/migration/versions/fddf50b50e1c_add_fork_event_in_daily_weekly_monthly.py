"""add fork event in daily, weekly, monthly

Revision ID: fddf50b50e1c
Revises: dbf1daf55faf
Create Date: 2017-03-12 14:59:25.391367

"""

revision = 'fddf50b50e1c'
down_revision = 'dbf1daf55faf'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import mysql


def upgrade():
    op.add_column('report_all_daily', sa.Column('cnt_fork', mysql.INTEGER(display_width=11), autoincrement=False, nullable=True) )
    op.add_column('report_all_monthly', sa.Column('cnt_fork', mysql.INTEGER(display_width=11), autoincrement=False, nullable=True) )
    op.add_column('report_all_weekly', sa.Column('cnt_fork', mysql.INTEGER(display_width=11), autoincrement=False, nullable=True) )


def downgrade():
    op.drop_column('report_all_daily', 'cnt_fork')
    op.drop_column('report_all_monthly', 'cnt_fork')
    op.drop_column('report_all_weekly', 'cnt_fork')
