"""add fork event in repos

Revision ID: 46245dde51a1
Revises: fddf50b50e1c
Create Date: 2017-03-12 15:01:36.676668

"""

revision = '46245dde51a1'
down_revision = 'fddf50b50e1c'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column('repos', sa.Column('forks_count', sa.Integer(), server_default='0', nullable=False))


def downgrade():
    op.drop_column('repos', 'forks_count')
