"""repos stars recording table to export excel file

Revision ID: 92fa38cbad6e
Revises: 35b046376e43
Create Date: 2017-03-24 18:00:29.264535

"""

revision = '92fa38cbad6e'
down_revision = '35b046376e43'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import mysql


def upgrade():
    op.create_table(
        'repos_stars_record',
        sa.Column('repo_id', sa.BigInteger(), nullable=False, primary_key=True),
        sa.Column(
            'year',
            mysql.SMALLINT(display_width=4, unsigned=True),
            autoincrement=False, nullable=False, primary_key=True
        ),
        sa.Column(
            'doy', mysql.SMALLINT(display_width=3, unsigned=True),
            autoincrement=False, nullable=False, primary_key=True
        ),
        sa.Column('cnt_sum', mysql.SMALLINT(display_width=4, unsigned=True), autoincrement=False, nullable=False),
        sa.Column('cnt_watch', mysql.SMALLINT(display_width=4), autoincrement=False, nullable=True, server_default='0'),
        sa.Column('cnt_fork', mysql.SMALLINT(display_width=4), autoincrement=False, nullable=True, server_default='0'),
        sa.Column('cnt_commit', mysql.SMALLINT(display_width=4), autoincrement=False, nullable=True, server_default='0'),
        sa.ForeignKeyConstraint(
            ['repo_id'], ['repos.id'], name='fk_repos_stars_record_repo_id', ondelete='CASCADE'
        ),
        sa.PrimaryKeyConstraint('repo_id', 'year', 'doy')
    )


def downgrade():
    op.drop_table('repos_stars_record')
