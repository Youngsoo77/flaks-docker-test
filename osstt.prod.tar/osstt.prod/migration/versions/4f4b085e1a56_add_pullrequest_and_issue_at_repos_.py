"""add pullrequest and issue at repos_stars_record

Revision ID: 4f4b085e1a56
Revises: 92fa38cbad6e
Create Date: 2017-06-21 12:11:14.423435

"""

revision = '4f4b085e1a56'
down_revision = '92fa38cbad6e'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import mysql


def upgrade():
    op.add_column('repos_stars_record', sa.Column('cnt_pullrequest', mysql.SMALLINT(display_width=4), autoincrement=False, nullable=True, server_default='0'))
    op.add_column('repos_stars_record', sa.Column('cnt_issue', mysql.SMALLINT(display_width=4), autoincrement=False, nullable=True, server_default='0'))


def downgrade():
    op.drop_column('repos_stars_record', 'cnt_pullrequest')
    op.drop_column('repos_stars_record', 'cnt_issue')
