"""add fork event in repos_stars

Revision ID: 7ffe7331dc35
Revises: 46245dde51a1
Create Date: 2017-03-12 15:02:47.518460

"""

revision = '7ffe7331dc35'
down_revision = '46245dde51a1'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import mysql


def upgrade():
    op.add_column('repos_stars', sa.Column('cnt_watch', mysql.INTEGER(display_width=11), autoincrement=False, nullable=True))
    op.add_column('repos_stars', sa.Column('cnt_fork', mysql.INTEGER(display_width=11), autoincrement=False, nullable=True))
    op.add_column('repos_stars', sa.Column('cnt_commit', mysql.INTEGER(display_width=11), autoincrement=False, nullable=True))


def downgrade():
    op.drop_column('repos_stars', 'cnt_watch')
    op.drop_column('repos_stars', 'cnt_fork')
    op.drop_column('repos_stars', 'cnt_commit')
