"""update default value in repos_starts count column

Revision ID: 6e2944dda8b4
Revises: 7ffe7331dc35
Create Date: 2017-03-12 15:31:51.708143

"""

revision = '6e2944dda8b4'
down_revision = '7ffe7331dc35'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import mysql


def upgrade():
    op.add_column('repos_stars', sa.Column('cnt_watch', mysql.INTEGER(display_width=4), autoincrement=False, nullable=True, server_default='0'))
    op.add_column('repos_stars', sa.Column('cnt_fork', mysql.INTEGER(display_width=4), autoincrement=False, nullable=True, server_default='0'))
    op.add_column('repos_stars', sa.Column('cnt_commit', mysql.INTEGER(display_width=4), autoincrement=False, nullable=True, server_default='0'))


def downgrade():
    op.drop_column('repos_stars', 'cnt_watch')
    op.drop_column('repos_stars', 'cnt_fork')
    op.drop_column('repos_stars', 'cnt_commit')
