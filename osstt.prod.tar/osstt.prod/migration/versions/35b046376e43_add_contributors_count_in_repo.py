"""add contributors count in repo

Revision ID: 35b046376e43
Revises: 6e2944dda8b4
Create Date: 2017-03-22 16:55:33.724555

"""

revision = '35b046376e43'
down_revision = '6e2944dda8b4'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column('repos', sa.Column('contributors', sa.Integer(), server_default='0', nullable=False))


def downgrade():
    op.drop_column('repos', 'contibutors')
