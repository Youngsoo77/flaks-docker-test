[![Coverage Status](https://coveralls.io/repos/bitbucket/invesume/oss_top_trending_repo/badge.svg)](https://coveralls.io/bitbucket/invesume/oss_top_trending_repo)

# About this project
이 프로젝트는 [gitmostwanted](https://github.com/kkamkou/gitmostwanted.com) 소스를 기반으로하여 개발되고 있는 오픈소스 트랜드 분석 소프트웨어입니다. 우리는 이 프로젝트를 통해서 새로운 오픈소스 트랜드 분석 알고리즘의 연구 개발과 최신의 데이터 분석 기법을 적용하여 가시화 시킬 것이며, 그 결과에 대해서 ICT 분야의 종사자들과 이해관계자 그리고 미래의 개발자들과의 공감대를 만들고 영감을 주는 것이 목표입니다.

# gitmostwanted
Advanced explorer of github.com. The main goal is to highlight the most interesting repositories and exclude others. You can find some concepts in the [Wiki](https://github.com/kkamkou/gitmostwanted.com/wiki).

## Donation
If you would like to help the project, please consider these topics:
- GMW uses [Google BigQuery](https://cloud.google.com/bigquery/pricing) and the service is pretty expensive.
- GMW is located on a private machine and hosted by [ProfitBricks](https://www.profitbricks.de/).

## Run (Python3)

```bash
# export PYTHONPATH="`pwd`:${PYTHONPATH}"
export GMW_APP_SETTINGS=/path/to/instance.cfg
python gitmostwanted/web.py
```

## Tests

```bash
py.test --pep8 --clearcache --cov gitmostwanted tests/unit
```

## Docker
The first time [it'll fail](https://github.com/docker/compose/issues/374)

```bash
cp instance.cfg.distr instance.cfg
[sudo] docker-compose up -d
# open http://127.0.0.1:5000/ in your browser
```

## License
The MIT License (MIT)

Copyright (c) 2015-2016 Kanstantsin Kamkou <2ka.by>